package cs3500.animator.model.shapes;

public enum ShapeType {
    RECTANGLE, OVAL
}
