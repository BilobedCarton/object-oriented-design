package cs3500.animator.view;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import cs3500.animator.model.ReadOnlySimpleAnimation;
import cs3500.animator.model.actions.AnimationAction;
import cs3500.animator.model.actions.ITimedAction;
import cs3500.animator.model.shapes.Shape;

/**
 * Represents a text based view for an animation program.
 */
public class TextView extends AbstractView {
  private Appendable out;

  /**
   * Creates a new {@code TextView} object.
   *
   * @param model is the model.
   * @param out   is the output location for this TextView, where we output the text to.
   */
  public TextView(ReadOnlySimpleAnimation model, Appendable out, double speed) {
    super(model, speed);
    this.out = out;
  }

  //in this case we output the shapes and such as a string.
  @Override
  public void update() {

    int[] shapeTimes = new int[getModel().getShapes().size()];
    for (int i = 0; i < getModel().getShapes().size(); i++) {
      shapeTimes[i] = getModel().getShapes().get(i).getAppearTick();
    }
    Arrays.sort(shapeTimes);
    String retString = "Shapes:\n";
    for (int i = 0; i < shapeTimes.length; i++) {
      for (int x = 0; x < getModel().getShapes().size(); x++) {
        if (shapeTimes[i] == getModel().getShapes().get(x).getAppearTick()) {
          retString += getModel().getShapes().get(x).toString(speed);
          break;
        }
      }
    }

    int[] actionTimes = new int[getModel().getActions().size()];
    for (int i = 0; i < getModel().getActions().size(); i++) {
      if (i == 0) {
        retString += "\n";
      }
      actionTimes[i] = getModel().getActions().get(i).getStartTick();
    }
    Arrays.sort(actionTimes);

    for (int i = 0; i < actionTimes.length; i++) {
      for (int x = 0; x < getModel().getActions().size(); x++) {
        if (actionTimes[i] == getModel().getActions().get(x).getStartTick()) {
          getModel().getActions().get(x).updateOriginalValues();
          retString += getModel().getActions().get(x).toString(speed);
          getModel().getActions().get(x).executeFinal();
          break;
        }
      }
    }

    try {
      out.append(retString);
    } catch (IOException e) {
      throw new IllegalStateException("error with writing file");
    }
  }
}
